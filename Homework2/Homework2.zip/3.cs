﻿    /*Problem 5. Boolean Variable
        • Declare a Boolean variable called  
        isFemale  and assign an appropriate 
        value corresponding to your gender.
        • Print it on the console.*/

using System;

namespace BooleanVariable
{
    class Program
    {
        static void Main()
        {
            bool female = false;
            Console.WriteLine("{0}", female);
        }
    }
}
