﻿
/*9. Exchange Variable Values
            • Declare two integer variables  a  and  b  
            and assign them with  5  and  10  and after that 
            exchange their values by using some programming logic.
            • Print the variable values before and after the exchange.*/

    using System;

    namespace ExchangeVariableValues
    {
        class Program
        {
            static void Main()
            {
                int a = 5;
                int b = 10;
                if (a == 5);
                if (b == 10) ;
                     Console.WriteLine(
                         "Oтпечатай befor: {0} {1}",a,b);
                if (a == 10) ;
                if (b == 5);
                    Console.WriteLine(
                        "Oтпечатай after: {1} {0}",a,b);
            }
        }
    }
